WhereWatch carrier v0.5, 5 pcs, two-sided assembly. Board 37.4 x 26.0 mm, 4 layers, 1.0 mm FR-4.
Top: U1 XIAO ESP32S3 Sense (Seeed SKU 113991115), U3 ATGM336H-5N31, L1, Q3, D1. Bottom: 28 parts.
J1/J4/J5 are JST SH SM02B-SRSS-TB (1.0 mm). Pick-and-place: wherewatch-carrier-v05-pick-and-place.csv (mm, KiCad rotation convention). J6 (SH 4-pin) may be left unpopulated if unavailable.
