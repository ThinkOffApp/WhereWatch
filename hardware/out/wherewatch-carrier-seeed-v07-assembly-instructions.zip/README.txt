WhereWatch carrier board - v0.7
Quantity: 5 pcs
Assembly: two-sided (PCBA both sides)

Top side: U1 Seeed XIAO ESP32S3 Sense SKU 113991115, U3 ATGM336H-5N31, L1
Bottom side: 30 parts per pick-and-place

Notes:
- J6 may be left unpopulated if unavailable.
- Polarity: D1 cathode per silkscreen.
- JST SH connectors J1/J4/J5 side-entry orientation per renders.

Files in this package:
- wherewatch-carrier-seeed-v07-pick-and-place.csv  (33 parts, both sides)
- wherewatch-carrier-v07-render-top.png             (F.Cu + F.Silkscreen + F.Fab)
- wherewatch-carrier-v07-render-bottom.png          (B.Cu + B.Silkscreen + B.Fab)
- wherewatch-carrier-v07-assembly-drawing-top.png   (F.Fab + F.Silkscreen references)
- wherewatch-carrier-v07-assembly-drawing-bottom.png(B.Fab + B.Silkscreen references)
- IMPEDANCE.txt                                     (controlled-impedance note, GNSS_RF net)
